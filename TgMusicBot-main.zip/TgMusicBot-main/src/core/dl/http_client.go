/*
 * TgMusicBot - Telegram Music Bot
 *  Copyright (c) 2025-2026 TEAMDEV
 *
 *  Licensed under GNU GPL v3
 *  See https://github.com/justfortestingnothibghere/TgMusicBot
 */

package dl

import (
	"ashokshau/tgmusic/config"
	"context"
	"crypto/rand"
	"errors"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"net/http"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"strings"
	"time"
)

const (
	defaultRequestTimeout = 30 * time.Second
	defaultConnectTimeout = 10 * time.Second
	maxRetries            = 2
	initialBackoff        = 1 * time.Second
)

var client = &http.Client{
	Timeout: defaultRequestTimeout,
	Transport: &http.Transport{
		TLSHandshakeTimeout:   defaultConnectTimeout,
		ResponseHeaderTimeout: defaultRequestTimeout,
		IdleConnTimeout:       90 * time.Second,
		MaxIdleConns:          100,
	},
}

// sendRequest performs an HTTP request with a given context, method, URL, body, and headers.
func sendRequest(ctx context.Context, method, fullURL string, body io.Reader, headers map[string]string) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, method, fullURL, body)
	if err != nil {
		log.Printf("Error creating request: %v", err)
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
	req.Header.Set("Accept", "*/*")

	for k, v := range headers {
		req.Header.Set(k, v)
	}

	var resp *http.Response
	var reqErr error
	backoff := initialBackoff

	for attempt := 0; attempt < maxRetries; attempt++ {
		if attempt > 0 {
			time.Sleep(backoff)
			backoff *= 2
		}

		resp, reqErr = client.Do(req)
		if reqErr == nil {
			if resp.StatusCode < 500 {
				return resp, nil // Success
			}
			if err := resp.Body.Close(); err != nil {
				log.Printf("failed to close response body: %v", err)
			}
			reqErr = fmt.Errorf("unexpected status code: %d", resp.StatusCode)
		} else if isTemporaryError(reqErr) {
			log.Printf("Temporary error on attempt %d/%d: %v", attempt+1, maxRetries, reqErr)
			continue // Retry on temporary errors
		} else {
			break // Do not retry on permanent errors
		}
	}

	if reqErr == nil {
		reqErr = fmt.Errorf("request failed after %d attempts", maxRetries)
	}

	return nil, fmt.Errorf("request failed: %w", reqErr)
}

// isTemporaryError determines if an error is temporary and thus worth retrying.
func isTemporaryError(err error) bool {
	var netErr net.Error
	if errors.As(err, &netErr) {
		return netErr.Timeout() || netErr.Temporary()
	}
	return false
}

// generateUniqueName creates a pseudo-random filename using a combination of the current timestamp and a random number.
func generateUniqueName(ext string) string {
	n, _ := rand.Int(rand.Reader, big.NewInt(99999))
	return fmt.Sprintf("%d_%05d%s", time.Now().UnixNano(), n.Int64(), ext)
}

// determineFilename safely determines a valid filename for a download.
func determineFilename(urlStr, contentDisp string) string {
	if filename := extractFilename(contentDisp); filename != "" {
		return filepath.Join(config.Conf.DownloadsDir, sanitizeFilename(filename))
	}

	if parsedURL, err := url.Parse(urlStr); err == nil {
		filename := path.Base(parsedURL.Path)
		if filename != "" && filename != "/" && !strings.Contains(filename, "?") {
			return filepath.Join(config.Conf.DownloadsDir, sanitizeFilename(filename))
		}
	}

	return filepath.Join(config.Conf.DownloadsDir, generateUniqueName(".tmp"))
}

// writeToFile writes data from an io.Reader to a specified file.
func writeToFile(filename string, data io.Reader) error {
	out, err := os.Create(filename)
	if err != nil {
		return fmt.Errorf("failed to create the file: %w", err)
	}
	defer func(out *os.File) {
		_ = out.Close()
	}(out)

	if _, err := io.Copy(out, data); err != nil {
		return fmt.Errorf("failed to write to the file: %w", err)
	}

	return nil
}

// DownloadFile downloads a file from a URL and saves it to a local path.
func DownloadFile(ctx context.Context, urlStr, fileName string, overwrite bool) (string, error) {
	if urlStr == "" {
		return "", errors.New("an empty URL was provided")
	}

	ctx, cancel := context.WithTimeout(ctx, downloadTimeout)
	defer cancel()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, urlStr, nil)
	if err != nil {
		return "", fmt.Errorf("failed to create the request: %w", err)
	}

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("the request failed: %w", err)
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("unexpected status code received: %d", resp.StatusCode)
	}

	if fileName == "" {
		fileName = determineFilename(urlStr, resp.Header.Get("Content-Disposition"))
	}

	if !overwrite {
		if _, err := os.Stat(fileName); err == nil {
			return fileName, nil // File already exists, no need to download again.
		}
	}

	if err := os.MkdirAll(filepath.Dir(fileName), defaultDownloadDirPerm); err != nil {
		return "", fmt.Errorf("failed to create the directory: %w", err)
	}

	tempPath := fileName + ".part"
	if err := writeToFile(tempPath, resp.Body); err != nil {
		return "", err
	}

	if err := os.Rename(tempPath, fileName); err != nil {
		return "", fmt.Errorf("failed to rename the temporary file: %w", err)
	}

	return fileName, nil
}
